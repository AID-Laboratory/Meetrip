# IoT-MS-Band_v2
 
기존 MS Band Application에서 센서데이터 디스플레이 기능을 추가하였음

## 사용전 필수 사항
1. Project Clone 및 import 후 Android Studio의 드롭다운 메뉴에서  
1. File/Invalidate Caches   
1. Build/rebuild project 진행